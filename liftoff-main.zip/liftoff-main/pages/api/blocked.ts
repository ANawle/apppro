import type { NextApiRequest, NextApiResponse } from "next";

export default function handler(_req: NextApiRequest, res: NextApiResponse) {
  res.status(200).json({
    error:
      "We love that you want to keep trying us out! Feel free to clone this repository in Vercel and continue using it yourself.",
  });
  return res.end();
}
